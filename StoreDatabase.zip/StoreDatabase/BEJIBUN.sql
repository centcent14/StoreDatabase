CREATE DATABASE bEJibun
GO
USE bEJibun
GO

CREATE TABLE MsCustomer (
	customerID CHAR(5) PRIMARY KEY NOT NULL CHECK(customerID LIKE 'CU[0-9][0-9][0-9]'),
	customerName VARCHAR(100) NOT NULL,
	customerGender VARCHAR(6) NOT NULL CHECK(customerGender LIKE 'Male' OR customerGender LIKE 'Female'),
	customerPhone VARCHAR(12) NOT NULL,
	customerDOB DATE NOT NULL CHECK(customerDOB BETWEEN '1990-01-01' AND CAST(GETDATE() AS DATE))
)

INSERT INTO MsCustomer VALUES
('CU001', 'Yovita Maimunah', 'Female' ,'081298491824', '1999 - 01 - 15'),
('CU002', 'Figo Ahmad', 'Male' ,'08129849170', '2001 - 06 - 20'),
('CU003', 'Kezia Ipeh', 'Female' ,'08129849165', '2002 - 10 - 28'),
('CU004', 'James Tanadi', 'Male' ,'08129849180', '2005 - 09 - 12'),
('CU005', 'Angel', 'Female' ,'08129849152', '1998 - 02 - 08'),
('CU006', 'Vanesa', 'Female' ,'08129849111', '1992 - 06 - 07'),
('CU007', 'Bob Sadino', 'Male' ,'08129849144', '1990 - 07 - 22'),
('CU008', 'Tom Holland', 'Male' ,'08129849179', '1995 - 06 - 19'),
('CU009', 'Pevita', 'Female' ,'085881702345', '2001 - 06 - 15'),
('CU010', 'Luxxy', 'Male' ,'085881702371', '2006 - 06 - 06'), 
('CU011', 'Zuxxy', 'Male' ,'081345678991', '1999 - 09 - 09'),
('CU012', 'Ryzen', 'Male' ,'085881702451', '2006 - 01 - 01'),
('CU013', 'Microboy', 'Male' ,'08588114210', '2001 - 08 - 05'),
('CU014', 'Liquid', 'Male' ,'085881702901', '2003 - 03 - 01'),
('CU015', 'Uhigh', 'Male' ,'081456788910', '2002 - 03 - 30'),
('CU016', 'Vania', 'Female' ,'08129849123', '1998 - 08 - 05'),
('CU017', 'Bob', 'Male' ,'08129849159', '1990 - 07 - 20'),
('CU018', 'Tom Cruise', 'Male' ,'08129849909', '1995 - 02 - 15'),
('CU019', 'Ryan Reynold', 'Female' ,'085881705565', '1992 - 01 - 17'),
('CU020', 'Made Bagus', 'Male' ,'085881701261', '1995 - 04 - 19')

CREATE TABLE MsStaff (
	staffID CHAR(5) PRIMARY KEY NOT NULL CHECK(staffID LIKE 'ST[0-9][0-9][0-9]'),
	staffName VARCHAR(100) NOT NULL,
	staffGender VARCHAR(6) NOT NULL CHECK(staffGender LIKE 'Male' OR staffGender LIKE 'Female'),
	staffPhone VARCHAR(12) NOT NULL,
	staffSalary INTEGER NOT NULL CHECK(staffSalary > 0)
)

INSERT INTO MsStaff VALUES
('ST001', 'Marcel', 'Male' ,'081775863204', 4500000),
('ST002', 'Gilbert', 'Male' ,'081443274798', 6000000),
('ST003', 'Dayutia', 'Female' ,'081330886865',4000000),
('ST004', 'Gibson', 'Male' ,'081913788621', 5500000),
('ST005', 'Tia', 'Female' ,'081802465204', 7000000),
('ST006', 'Metta', 'Female' ,'081843606029', 3000000),
('ST007', 'Jerry', 'Male' ,'081508474365', 4000000),
('ST008', 'Jason', 'Male' ,'081385423414', 5000000),
('ST009', 'Aurel', 'Female' ,'081425405075', 2000000),
('ST010', 'Lia', 'Female' ,'081203632962', 4000000), 
('ST011', 'Adam', 'Male' ,'081978276403', 2000000),
('ST012', 'Habel', 'Male' ,'08144327879', 3000000),
('ST013', 'Yohanes', 'Male' ,'081218394520', 2500000),
('ST014', 'Petrus', 'Male' ,'08133088685', 2000000),
('ST015', 'Simon', 'Male' ,'081347815332', 3000000),
('ST016', 'Aca', 'Female' ,'088319275364', 5000000),
('ST017', 'Tony', 'Male' ,'081415890362', 4500000),
('ST018', 'Korpai', 'Male' ,'081203632962', 6000000),
('ST019', 'Jangs', 'Female' ,'081385423414', 7000000),
('ST020', 'Babyla', 'Female' ,'081909698019', 8000000) 

CREATE TABLE MsVendor (
	vendorID CHAR(5) PRIMARY KEY NOT NULL CHECK(vendorID LIKE 'VE[0-9][0-9][0-9]'),
	vendorName VARCHAR(100) NOT NULL,
	vendorPhone VARCHAR(12) NOT NULL,
	vendorAddress VARCHAR(100) NOT NULL CHECK(vendorAddress LIKE '%Street'),
	vendorEmail VARCHAR(50) NOT NULL CHECK(vendorEmail LIKE '%@%.com')
)

INSERT INTO MsVendor VALUES
('VE001', 'Caryl', '081872212611', 'Roxburgh Town Street','caryl@yahoo.com'),
('VE002', 'Agustinus', '081928228584', 'Kalimantan Street', 'agustinus@yahoo.com'),
('VE003', 'Lydia', '081304534926', 'Sulawesi Street', 'lydia@yahoo.com'),
('VE004', 'Agus', '081843606029',  'Sumatra Street', 'agus@gmail.com'),
('VE005', 'Rachel', '081323621529', 'Food Street', 'rachel@yahoo.com'),
('VE006', 'Gabriela', '081662855167', 'Jambi Street', 'gabriela@gmail.com'),
('VE007', 'Alexander', '081209651523', 'Rose Haven Street', 'alexander@yahoo.com'),
('VE008', 'Graham', '081510905847', 'Dunlora Street', 'graham@yahoo.com'),
('VE009', 'Stevana', '081484488709',  'Losa Street', 'stevana@yahoo.com'),
('VE010', 'Angelika', '081304534926',  'Damson Lea Street', 'angelika@yahoo.com'), 
('VE011', 'Haliman', '081937404581',  'Epsom Street', 'haliman@yahoo.com'),
('VE012', 'Ivan', '081802465204', 'Broadway Street' , 'ivan@yahoo.com'),
('VE013', 'Maria', '081347722168', 'East Alley Street', 'maria@gmail.com'),
('VE014', 'Tahjadi', '081229231160', 'Eastwood Ridgeway Street', 'tahjadi@yahoo.com'),
('VE015', 'Garry', '081662855167', 'Empire Street', 'garry@gmail.com'),
('VE016', 'Pondzai', '081662855123', 'Food Street', 'pondzai@gmail.com'),
('VE017', 'Vintorez', '081209651666', 'Faze Street', 'vintorez@yahoo.com'),
('VE018', 'mika', '081510905555', 'Dunlora Street', 'mika@yahoo.com'),
('VE019', 'miya', '081484488678',  'Lisa Street', 'miya@yahoo.com'),
('VE020', 'hylos', '081304534269',  'Lea Street', 'hylos@yahoo.com') 

CREATE TABLE MsItemCategory (
	itemTypeID CHAR(5) PRIMARY KEY NOT NULL CHECK(itemTypeID LIKE 'IP[0-9][0-9][0-9]'),
	itemTypeName VARCHAR(100) NOT NULL CHECK(LEN(itemTypeName) >= 4)
)

INSERT INTO MsItemCategory VALUES
('IP001', 'Electronics'),
('IP002', 'Workspace'),
('IP003', 'Food'),
('IP004', 'Drink'),
('IP005', 'Accessories'),
('IP006', 'Gadget'),
('IP007', 'Sport'),
('IP008', 'Storage'),
('IP009', 'Bathroom'),
('IP010', 'Hygiene equipment'), 
('IP011', 'Dinning set'),
('IP012', 'Bedroom set'),
('IP013', 'Clothes set'),
('IP014', 'Household appliances'),
('IP015', 'Smart home')

CREATE TABLE MsItem (
	itemID CHAR(5) PRIMARY KEY NOT NULL CHECK(itemID LIKE 'IT[0-9][0-9][0-9]'),
	itemTypeID CHAR(5) FOREIGN KEY REFERENCES MsItemCategory(itemTypeID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	itemName VARCHAR(100) NOT NULL,
	itemPrice INTEGER NOT NULL CHECK(itemPrice > 0),
	minimumPurchase INTEGER NOT NULL
)

INSERT INTO MsItem VALUES
('IT001', 'IP001', 'Handphone', '3000000','1'),
('IT002', 'IP001', 'TV', '6000000','1'),
('IT003', 'IP002', 'Desk organizer', '500000','1'),
('IT004', 'IP002', 'Sticky notes', '20000','1'),
('IT005', 'IP003', 'Wagyu A5', '6000000','4'),
('IT006', 'IP003', 'Kentang Goreng', '300000','10'),
('IT007', 'IP004', 'Freshtea', '60000','7'),
('IT008', 'IP004', 'Kopi Kenangan', '45000','8'),
('IT009', 'IP005', 'Sofa cushion', '4000000','1'),
('IT010', 'IP005', 'Textile', '2000000','1'),
('IT011', 'IP006', 'iPhone', '50000000','1'),
('IT012', 'IP006', 'iPad', '3000000','1'),
('IT013', 'IP007', 'Tennis table', '3500000','1'),
('IT014', 'IP007', 'Badminton set', '3000000','1'),
('IT015', 'IP008', 'Box and organizer', '1000000','1'),
('IT016', 'IP008', 'Cupboard', '4500000','1'),
('IT017', 'IP009', 'Bathub', '10000000','1'),
('IT018', 'IP009', 'Towels', '600000','1'),
('IT019', 'IP010', 'Laundry machine', '15000000','1'),
('IT020', 'IP010', 'Detergent', '80000','1'),
('IT021', 'IP011', 'Dinning table', '5000000','1'),
('IT022', 'IP011', 'Dinning chair', '4500000','1'),
('IT023', 'IP012', 'Pillow', '400000','1'),
('IT024', 'IP012', 'Sheet', '200000','1'),
('IT025', 'IP013', 'Clothes hanger', '100000','1'),
('IT026', 'IP013', 'Hoodie', '700000','1'),
('IT027', 'IP014', 'Cooking set', '1500000','1'),
('IT028', 'IP014', 'Scales and gauges', '800000','1'),
('IT029', 'IP015', 'Wireless charging', '1000000','1'),
('IT030', 'IP015', 'Smart lamp', '900000','1')

CREATE TABLE HeaderSalesTransaction (
	salesID CHAR(5) PRIMARY KEY NOT NULL CHECK(salesID LIKE 'SA[0-9][0-9][0-9]'),
	staffID CHAR(5) FOREIGN KEY REFERENCES MsStaff(staffID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	customerID CHAR(5) FOREIGN KEY REFERENCES MsCustomer(customerID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	salesDate DATE NOT NULL
)

INSERT INTO HeaderSalesTransaction VALUES
('SA001', 'ST001', 'CU001', '2019-02-01'),
('SA002', 'ST002', 'CU002', '2019-02-07'),
('SA003', 'ST003', 'CU003', '2019-04-02'), 
('SA004', 'ST004', 'CU004', '2019-04-08'), 
('SA005', 'ST005', 'CU005', '2019-06-10'), 
('SA006', 'ST006', 'CU006', '2020-07-18'), 
('SA007', 'ST007', 'CU007', '2020-08-20'), 
('SA008', 'ST008', 'CU008', '2020-09-16'), 
('SA009', 'ST009', 'CU009', '2020-10-14'), 
('SA010', 'ST010', 'CU010', '2020-11-12'), 
('SA011', 'ST011', 'CU011', '2021-12-10'), 
('SA012', 'ST012', 'CU012', '2021-07-08'), 
('SA013', 'ST013', 'CU013', '2021-06-12'), 
('SA014', 'ST014', 'CU014', '2021-04-04'), 
('SA015', 'ST015', 'CU015', '2021-05-02'),
('SA016', 'ST016', 'CU016', '2021-06-01'), 
('SA017', 'ST017', 'CU017', '2021-08-25'), 
('SA018', 'ST018', 'CU018', '2021-10-26'), 
('SA019', 'ST019', 'CU019', '2021-06-30'), 
('SA020', 'ST020', 'CU020', '2021-08-01')

CREATE TABLE SalesTransactionDetail (
	salesID CHAR(5) FOREIGN KEY REFERENCES HeaderSalesTransaction(salesID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	itemID CHAR(5) FOREIGN KEY REFERENCES MsItem(itemID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	quantity INTEGER NOT NULL,
	PRIMARY KEY (salesID, itemID)
)

INSERT INTO SalesTransactionDetail VALUES
('SA001', 'IT001', '10'),
('SA002', 'IT002', '15'),
('SA003', 'IT003', '6'),
('SA004', 'IT004', '4'),
('SA005', 'IT005', '6'),
('SA006', 'IT006', '5'),
('SA007', 'IT007', '3'),
('SA008', 'IT008', '5'),
('SA009', 'IT009', '7'),
('SA010', 'IT010', '9'),
('SA011', 'IT011', '2'),
('SA012', 'IT012', '4'),
('SA013', 'IT013', '8'),
('SA014', 'IT014', '10'),
('SA015', 'IT015', '2'),
('SA016', 'IT016', '8'),
('SA016', 'IT023', '7'),
('SA017', 'IT017', '2'),
('SA017', 'IT021', '3'),
('SA018', 'IT018', '3'),
('SA018', 'IT022', '4'),
('SA019', 'IT019', '4'),
('SA019', 'IT023', '2'),
('SA020', 'IT020', '3'),
('SA020', 'IT024', '5')



CREATE TABLE HeaderPurchaseTransaction (
	purchaseID CHAR(5) PRIMARY KEY NOT NULL CHECK(purchaseID LIKE 'PH[0-9][0-9][0-9]'),
	staffID CHAR(5) FOREIGN KEY REFERENCES MsStaff(staffID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	vendorID CHAR(5) FOREIGN KEY REFERENCES MSVendor(vendorID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	purchaseDate DATE NOT NULL,
	arrivalDate DATE
)

INSERT INTO HeaderPurchaseTransaction VALUES
('PH001', 'ST001', 'VE001', '2017-02-06', NULL),
('PH002', 'ST002', 'VE002', '2019-04-02', '2019-12-12'), 
('PH003', 'ST003', 'VE003', '2017-06-04', NULL),
('PH004', 'ST004', 'VE004', '2018-08-06', '2019-12-20'), 
('PH005', 'ST005', 'VE005', '2017-04-10', NULL),
('PH006', 'ST006', 'VE006', '2016-06-12', '2019-10-25'), 
('PH007', 'ST007', 'VE007', '2017-08-14', NULL),
('PH008', 'ST008', 'VE008', '2018-10-16', '2019-12-31'), 
('PH009', 'ST009', 'VE009', '2019-12-18', NULL), 
('PH010', 'ST010', 'VE010', '2020-12-20', '2021-01-01'), 
('PH011', 'ST011', 'VE011', '2017-12-21', NULL),
('PH012', 'ST012', 'VE012', '2018-11-26', '2019-08-02'), 
('PH013', 'ST013', 'VE013', '2020-09-15', NULL),
('PH014', 'ST014', 'VE014', '2018-07-06', '2020-12-28'), 
('PH015', 'ST015', 'VE015', '2021-05-07', NULL),
('PH016', 'ST016', 'VE016', '2019-03-05', '2020-12-01'), 
('PH017', 'ST017', 'VE017', '2019-01-01', '2020-12-15'), 
('PH018', 'ST018', 'VE018', '2020-12-28', '2021-01-05'),
('PH019', 'ST019', 'VE019', '2021-01-06', '2021-02-07'), 
('PH020', 'ST020', 'VE020', '2020-02-22', '2020-02-28') 

CREATE TABLE PurchaseTransactionDetail (
	purchaseID CHAR(5) FOREIGN KEY REFERENCES HeaderPurchaseTransaction(purchaseID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	itemID CHAR(5) FOREIGN KEY REFERENCES MsItem(itemID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	quantity INTEGER NOT NULL,
	PRIMARY KEY (purchaseID, itemID)
)

INSERT INTO PurchaseTransactionDetail VALUES
('PH001', 'IT001', '100'),
('PH002', 'IT002', '150'),
('PH003', 'IT003', '70'),
('PH004', 'IT004', '130'),
('PH005', 'IT005', '120'),
('PH006', 'IT006', '50'),
('PH007', 'IT007', '80'),
('PH008', 'IT008', '170'),
('PH009', 'IT009', '200'),
('PH010', 'IT010', '60'),
('PH011', 'IT011', '90'),
('PH012', 'IT012', '110'),
('PH013', 'IT013', '130'),
('PH014', 'IT014', '140'),
('PH015', 'IT015', '250'),
('PH016', 'IT016', '60'),
('PH017', 'IT017', '80'),
('PH018', 'IT018', '90'),
('PH019', 'IT019', '70'),
('PH020', 'IT020', '40')

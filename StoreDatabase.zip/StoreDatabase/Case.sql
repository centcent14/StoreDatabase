USE bEJibun

--1
SELECT itemName, itemPrice, SUM(quantity) AS ItemTotal
FROM MsItem
JOIN PurchaseTransactionDetail ON MsItem.itemID = PurchaseTransactionDetail.itemID
JOIN HeaderPurchaseTransaction ON PurchaseTransactionDetail.purchaseID = HeaderPurchaseTransaction.purchaseID
WHERE arrivalDate IS NULL
GROUP BY itemName, itemPrice
HAVING SUM(quantity) > 100
ORDER BY ItemTotal DESC

--2
SELECT MV.vendorName,SUBSTRING(MV.vendorEmail,(CHARINDEX('@',MV.vendorEmail)+1),(LEN(MV.vendorEmail)-CHARINDEX('@',MV.vendorEmail)+1)) AS [Domain Name], AVG(PD.quantity) AS [Average Purchased Item]
FROM MsVendor MV join HeaderPurchaseTransaction HP ON MV.vendorID=HP.vendorID
join PurchaseTransactionDetail PD ON HP.purchaseID=PD.purchaseID
WHERE (SUBSTRING(vendorEmail,(CHARINDEX('@',vendorEmail)+1),(LEN(vendorEmail)-CHARINDEX('@',vendorEmail)+1)) not like 'gmail.com' and MV.vendorAddress like 'Food Street')
GROUP BY vendorName,vendorEmail

--3
SELECT MONTH(HS.salesDate) AS [Month],MIN(ST.quantity) OVER(PARTITION BY MC.itemTypeID) AS [Minimum Quantity Sold], MAX(ST.quantity) OVER(PARTITION BY MC.itemTypeID) AS [Maximum Quantity Sold]
from HeaderSalesTransaction HS join SalesTransactionDetail ST ON HS.salesID=ST.salesID
join MsItem MT ON ST.itemID=MT.itemID
join MsItemCategory MC ON  MT.itemTypeID=MC.itemTypeID
WHERE (YEAR(HS.salesDate) like '2019' AND MC.itemTypeName not like 'Food' AND MC.itemTypeName not like 'Drink')


--4
SELECT REPLACE(MS.staffID,'ST', 'Staff ') AS [Staff Number],staffName,CONCAT('Rp. ',Ms.staffSalary) AS [Salary],COUNT(HS.salesID) AS [Sales Count], AVG(ST.quantity) AS [Average Sales Quantity]
FROM MsStaff MS join HeaderSalesTransaction HS ON MS.staffID=HS.staffID
join SalesTransactionDetail ST ON HS.salesID= ST.salesID
join MsCustomer MC ON HS.customerID=MC.customerID
WHERE ((MS.staffID=HS.staffID) AND ((MC.customerGender like 'Male' AND MS.staffGender like 'Female')OR (MC.customerGender like 'Female' AND MS.staffGender like 'Male')) AND MONTH(HS.salesDate)=2)
GROUP BY MS.staffID,MS.staffName,MS.staffSalary

--5
SELECT CONCAT(SUBSTRING(MsCustomer.customerName,1,1),SUBSTRING(MsCustomer.customerName,LEN(MsCustomer.customerName),1)) AS[Customer Initial], FORMAT(salesDate,'MM/dd/yyyy') AS [Transaction Date], SalesTransactionDetail.quantity AS [Quantity]
FROM MsCustomer
JOIN HeaderSalesTransaction ON MsCustomer.customerID = HeaderSalesTransaction.customerID
JOIN SalesTransactionDetail ON HeaderSalesTransaction.salesID = SalesTransactionDetail.salesID
WHERE (MsCustomer.customerGender = 'Female' AND quantity > (SELECT sum(quantity)/count(quantity) from SalesTransactionDetail))
GROUP BY MsCustomer.customerName, salesDate,SalesTransactionDetail.quantity

--6
SELECT LOWER(MV.vendorID) AS [ID],vendorName,STUFF(MV.vendorPhone,1,1,'+62') AS [Phone Number]
FROM MsVendor MV join HeaderPurchaseTransaction HP ON MV.vendorID=HP.vendorID
join PurchaseTransactionDetail PT ON HP.purchaseID = PT.purchaseID
WHERE (PT.quantity > (SELECT MIN(quantity) from PurchaseTransactionDetail) AND CAST(SUBSTRING(PT.itemID,3,3) AS INTEGER) % 2 =1)

--7
SELECT  MS.staffName AS [StaffName], MV.vendorName,HP.purchaseID,SUM(PT.quantity) AS [Total Purchased Quantity], CAST(DATEDIFF(DAY,HP.purchaseDate,CAST(GETDATE()AS DATE))AS VARCHAR(10)) + ' Days ago' AS [Ordered Day]
FROM HeaderPurchaseTransaction HP JOIN MsStaff MS ON HP.staffID=MS.staffID
JOIN PurchaseTransactionDetail PT ON HP.purchaseID=PT.purchaseID
JOIN MsVendor MV ON MV.vendorID=HP.vendorID
WHERE ((SELECT SUM(quantity)FROM PurchaseTransactionDetail)>(SELECT MAX(quantity) FROM PurchaseTransactionDetail) AND DATEDIFF(DAY,HP.purchaseDate,HP.arrivalDate)<7)
GROUP BY staffName,vendorName,HP.purchaseID,purchaseDate


--8
SELECT TOP 2 FORMAT(HS.salesDate,'dddd') AS [Day], COUNT (ST.quantity) AS [Item Sales Amount]
FROM HeaderSalesTransaction HS JOIN SalesTransactionDetail ST ON HS.salesID = ST.salesID
JOIN MsItem MI ON ST.itemID= MI.itemID
JOIN MsItemCategory MIC ON MI.itemTypeID=MIC.itemTypeID
WHERE MI.itemPrice < (SELECT AVG(itemPrice) FROM MsItem) AND MIC.itemTypeName = 'Electronic' OR MIC.itemTypeName = 'Gadget'
GROUP BY HS.salesDate
ORDER BY COUNT(ST.quantity) ASC

--9
CREATE VIEW [Customer Statistic By Gender] 
AS
SELECT customerGender,MAX(ST.quantity) AS[Maximum Sales], MIN(ST.quantity) AS [Minimum Sales] 
FROM MsCustomer MC JOIN  HeaderSalesTransaction HS ON MC.customerID=HS.customerID
JOIN SalesTransactionDetail ST ON HS.salesID=ST.salesID
WHERE (ST.quantity between 10 and 50 AND YEAR(customerDOB) BETWEEN 1998 AND 1999)
GROUP BY customerGender

SELECT *FROM [Customer Statistic By Gender]

--10
CREATE VIEW [Item Type Statistic] AS
SELECT UPPER(MIC.itemTypeName) AS[Item Type], AVG(itemPrice) AS [Average Price], COUNT(MI.itemName) AS [Number Of Item Variety] 
FROM MsItem MI JOIN MsItemCategory MIC ON MI.itemTypeID=MIC.itemTypeName 
WHERE (MIC.itemTypeName like 'F%' AND MI.minimumPurchase > 5)
GROUP BY MIC.itemTypeName


SELECT * FROM [Item Type Statistic]